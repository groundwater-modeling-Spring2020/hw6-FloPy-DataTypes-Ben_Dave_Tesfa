# _hw6-FloPy-DataTypes_Final

This folder is for the final notebook containing what we read, found, or did.